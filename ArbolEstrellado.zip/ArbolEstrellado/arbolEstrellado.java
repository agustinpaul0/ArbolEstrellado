import java.util.Scanner;

public class arbolEstrellado {
    public static void main (String a[]) {
        //Creo un objeto scanner para leer entrada de datos del usuario
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese el número de filas de su árbol estrellado: ");
        int filas = Integer.parseInt(scanner.nextLine());

        String estrellas = "*";
        int espacios = filas-1;
        
        for (int i = 0; i < filas; i++) {
            for (int aux = 0; aux < espacios; aux++) {
                System.out.print(" ");
            }
            System.out.println(estrellas);
            estrellas += "**"; //Cada fila tiene 2 estrellas más con respecto a la anterior
            espacios--;
        }
    }
}